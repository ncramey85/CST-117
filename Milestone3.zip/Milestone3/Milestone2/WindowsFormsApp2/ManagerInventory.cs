﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class ManagerInventory
    {
        private List<Inventory> managerInvenotryList = new List<Inventory>();
        public void addItem(Inventory item)
        {
            this.managerInvenotryList.Add(item);
        }
        public void removeItem(Inventory item)
        {
            this.managerInvenotryList.Remove(item);
        }
        public void restockItem(Inventory item, int restock)
        {
            int index = 0;
            if (restock > 0)
            {
            while (index < restock)
                {
                    this.managerInvenotryList.Add(item);
                    index++;
                }
            }
        }
        public void inventoryDisplay()
        {
        foreach (Inventory electronics in this.managerInvenotryList)
            {
                Console.WriteLine(" Equipment = " + electronics.Equipment + ", Part Number " + electronics.PartNumber + ", Serial Number " + electronics.SerialNumber + ", Quantity " + electronics.Quantity);
            }
        }
        public List<int> equipmentSearch(string objectName)
        {
            List<int> itemLocation = new List<int>();
            foreach (Inventory item in this.managerInvenotryList)
            {
                if (String.Equals(item.Equipment, objectName, StringComparison.OrdinalIgnoreCase))
                {
                    itemLocation.Add(this.managerInvenotryList.IndexOf(item));
                }
            }
            return itemLocation;
        }
        public List<int> partNumberSearch (string objectPartNumber)
        {
            List<int> itemLocation = new List<int>();
            foreach (Inventory item in this.managerInvenotryList)
            {
            if (String.Equals(item.PartNumber, objectPartNumber, StringComparison.OrdinalIgnoreCase ))
                {
                    itemLocation.Add(this.managerInvenotryList.IndexOf(item));
                }
            }
            return itemLocation;
        }
    }
}
