﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string quantity;
            string equipment;
            string partnumber;
            string serialnumber;
            quantity = textBox5.Text;
            equipment = textBox1.Text;
            partnumber = textBox2.Text;
            serialnumber = textBox3.Text;
            Inventory item1 = new Inventory(quantity, equipment, partnumber, serialnumber);
            MessageBox.Show(string.Format(" The equipment added is {0}, {1}, {2} ", item1.Equipment, item1.PartNumber, item1.SerialNumber));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Inventory item1 = new Inventory("DMM, E1410A, MY50004321, QTY:1");
            Inventory item2 = new Inventory("CTR, E1420B, A00234512, QTY:1");
            Inventory item3 = new Inventory("DSO, WS-42XS, LCRY43212125, QTY:1");
            Inventory item4 = new Inventory("SRM, A5410-30-1, MY23489023, QTY:1");
            Inventory item5 = new Inventory("SCM, L1SCM0300200, V120982, QTY:1");

            ManagerInventory TempeStock = new ManagerInventory();

            TempeStock.addItem(item1);
            TempeStock.addItem(item2);
            TempeStock.addItem(item3);
            TempeStock.addItem(item4);
            TempeStock.addItem(item5);

            Console.WriteLine(" Show objects before removing them. ");
            TempeStock.inventoryDisplay();
            

            TempeStock.removeItem(item1);
            TempeStock.removeItem(item2);
            TempeStock.removeItem(item3);
            Console.WriteLine("");
            Console.WriteLine("These were removed.");
            TempeStock.inventoryDisplay();

            TempeStock.restockItem(item5,5);
            Console.WriteLine("");
            Console.WriteLine(" These were restocked ");
            TempeStock.inventoryDisplay();
        }
    }
}