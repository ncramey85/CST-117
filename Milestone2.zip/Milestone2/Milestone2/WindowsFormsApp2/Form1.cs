﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string quantity;
            string equipment;
            string partnumber;
            string serialnumber;
            quantity = textBox5.Text;
            equipment = textBox1.Text;
            partnumber = textBox2.Text;
            serialnumber = textBox3.Text;
            Inventory item1 = new Inventory( quantity, equipment, partnumber, serialnumber);
            MessageBox.Show(string.Format(" The equipment added is {0}, {1}, {2} ", item1.Equipment, item1.PartNumber, item1.SerialNumber));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
