﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Inventory
    {
        private string itemQuantity;
        private string itemEquipment;
        private string itemPartNumber;
        private string itemSerialNumber;

        public string Quantity
        {
            get { return itemQuantity; }
            set { itemQuantity = value; }
        }
        public string Equipment
        {
            get { return itemEquipment; }
            set { itemEquipment = value; }
        }
        public string PartNumber
        {
            get { return itemPartNumber; }
            set { itemPartNumber = value; }
        }
        public string SerialNumber
        {
            get { return itemSerialNumber; }
            set { itemSerialNumber = value; }
        }
        public Inventory(string itemQuantity, string itemEquipment, string itemPartNumber, string itemSerialNumber )
        {
            this.itemQuantity = itemQuantity;
            this.itemEquipment = itemEquipment;
            this.itemPartNumber = itemPartNumber;
            this.itemSerialNumber = itemSerialNumber;
        }
        public Inventory()
        {
            itemQuantity = "none";  
            itemEquipment = "None";
            itemPartNumber = "none";
            itemSerialNumber = "none";
        }
    }
}
