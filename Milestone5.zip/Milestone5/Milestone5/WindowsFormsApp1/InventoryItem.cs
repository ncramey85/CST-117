﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class InventoryItem
    {
        private int itemCategory;
        private string itemEquipment;
        private int itemPartNumber;
        private decimal itemSerialNumber;
        private DateTime dateAdded;

        public int Category { get => itemCategory; set => itemCategory = value; }
        public string Equipment { get => itemEquipment; set => itemEquipment = value; }
        public int PartNumber { get => itemPartNumber; set => itemPartNumber = value; }
        public decimal SerialNumber { get => itemSerialNumber; set => itemSerialNumber = value; }
        public DateTime DateAdded { get => dateAdded; set => dateAdded = value; }

        public InventoryItem()
        {
            itemCategory = 1;
            itemEquipment = "DMM";
            itemPartNumber = 340923;
            itemSerialNumber = 7456982;
            dateAdded = System.DateTime.Now;
        }
        public InventoryItem(int itemCategory, string itemEquipment, int itemPartNumber, decimal itemSerialNumber, DateTime dateAdded)
        {
            this.itemCategory = itemCategory;
            this.itemEquipment = itemEquipment;
            this.itemPartNumber = itemPartNumber;
            this.itemSerialNumber = itemSerialNumber;
            this.DateAdded = dateAdded;
        }
        public void print()
        {
            Console.Write("ID #" + itemCategory + "\n" + itemEquipment + "\n" + itemPartNumber + "\n" + itemSerialNumber + "\n" + dateAdded + "\n");
        }
    }
}
    

