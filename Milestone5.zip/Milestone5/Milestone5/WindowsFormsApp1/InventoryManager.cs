﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApp1
{
    class InventoryManager
    {
        
        List<InventoryItem> inventory = new List<InventoryItem>();
        public InventoryManager()
        {
        
        }
        public void addItem(int itemCategory, string itemEquipment, int itemPartNumber, decimal itemSerialNumber, DateTime dateAdded)
        {
            InventoryItem item = new InventoryItem(itemCategory, itemEquipment, itemPartNumber, itemSerialNumber, dateAdded);
            inventory.Add(item);
        }

        internal void addItem(int v1, string v2, decimal v3, double v4, DateTime dateTime)
        {
            throw new NotImplementedException();
        }

        public void AddItem(InventoryItem item) { inventory.Add(item); }
        public void RemoveItem(InventoryItem item) { inventory.Remove(item); }
        public void restock(int quantity, InventoryItem item)
        {
            for (int i = 0; i < quantity; i++)
            {
                AddItem(item);
            }
        }
        public void Search(string Category)
        {
            InventoryItem locate = new InventoryItem();
            int category = 0;
            locate = inventory.Find(x => x.Category == category);
            if (locate == null)
            {
                Console.WriteLine("Item Not found");
            }
            else locate.print();
        }
        public void search(decimal SerialNumber)
        {
            InventoryItem locate = new InventoryItem();
            int serialNumber = 0;
            locate = inventory.Find(x => x.SerialNumber == serialNumber);
            if (locate == null)
            {
                Console.WriteLine("Item Not found");
            }
            else locate.print();
        }
        internal void search(string text)
        {
            throw new NotImplementedException();
        }
        public void printAll()
        {
            Console.WriteLine("Inventory:");
            foreach (var item in inventory)
            {
                item.print();
            }
        }
    }
}
    

