﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        InventoryManager inventory = new InventoryManager();
        InventoryItem invItem = new InventoryItem();
        DateTime dateTime = System.DateTime.Now;

        public Form1()
        {
            InitializeComponent();
        }
        private void updateListView() { }

        private void button4_Click(object sender, EventArgs e)
        {
            InventoryItem item = new InventoryItem(1, "DMM", 54892, 781412, dateTime);
            inventory.AddItem(item);

            // creates the loop 
            ListViewItem lvi = new ListViewItem(item.Category.ToString());
            lvi.SubItems.Add(item.PartNumber.ToString());
            lvi.SubItems.Add(item.ToString());
            lvi.SubItems.Add(item.SerialNumber.ToString());
            listView1.Items.Add(lvi);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            InventoryItem result = new InventoryItem();
            inventory.search(textBoxSearch.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {  
          inventory.addItem(Convert.ToInt32(textBoxCategory.Text),
          textBoxEquipment.ToString(),
          Convert.ToDecimal(textBoxSerialNumber),
          Convert.ToDouble(textBoxPartNumber),
          dateTime);     
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
