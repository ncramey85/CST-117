﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void startButton1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            const int ROWS = 3;
            const int COLUMNS = 3;
            int[,] boardGame = new int[ROWS, COLUMNS];
            for (int row = 0; row < ROWS; row++)
            {
                for (int col = 0; col < COLUMNS; col++)
                {
                    boardGame[row, col] = rand.Next(2);
                }
            }
            label1.Text = getValue(boardGame[0, 0]);
            label2.Text = getValue(boardGame[0, 1]);
            label3.Text = getValue(boardGame[0, 2]);
            label4.Text = getValue(boardGame[1, 0]);
            label5.Text = getValue(boardGame[1, 1]);
            label6.Text = getValue(boardGame[1, 2]);
            label7.Text = getValue(boardGame[2, 0]);
            label8.Text = getValue(boardGame[2, 1]);
            label9.Text = getValue(boardGame[2, 2]);
            
        }
        public string getValue(int XOvalue)
        {
            if (XOvalue == 0)
            {
                return "0";
            }
            else
            {
                return "X";
            }
        }
        public string XOwinner (int[,] intArray)
        {
            int winner = -1;
            if ((intArray[0, 0] == intArray[0, 0] && (intArray[0, 1] == intArray[0, 2])))
            {
                winner = intArray[0, 0];
            }
            if ((intArray[1, 0] == intArray[1, 0] && (intArray[1,1 ] == intArray[1, 2])))
            {
                winner = intArray[1, 0];
            }
            if ((intArray[2, 0] == intArray[2, 0] && (intArray[2, 1] == intArray[2, 2])))
            {
                winner = intArray[2, 0]; 
            }

            if ((intArray[0, 0] == intArray[0, 0] && (intArray[1, 1] == intArray[2, 0])))
            {
                winner = intArray[0, 0];
            }
            if ((intArray[0, 1] == intArray[0, 1] && (intArray[1, 1] == intArray[2, 1])))
            {
                winner = intArray[0, 1];
            }
            if ((intArray[0, 2] == intArray[0, 2] && (intArray[1, 2] == intArray[2, 2])))
            {
                winner = intArray[0, 2];
            }

            if ((intArray[0, 0] == intArray[0, 0] && (intArray[1, 1] == intArray[2, 2])))
            {
                winner = intArray[0, 0];
            }
            if ((intArray[0, 2] == intArray[0, 2] && (intArray[1, 1] == intArray[2, 0])))
            {
                winner = intArray[0, 2];
            }
        
            if (winner == 0)
            {
                MessageBox.Show("0 won that trash");
                
            }
            else if (winner == 1)
            {
                MessageBox.Show("X won that Trash");
                
            }
            else
            {
                return "X & O tied";
            }
            return "XO";
        }   

        private void closeButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetButton2_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
        }
    }
}
