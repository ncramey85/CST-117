﻿using System;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static string stripPunc(string words)
        {
            words = words.Trim(new Char[] { ' ', '.', '*', ',', '!', '?'});
            return words;
        }
        static void Main(string[] args)
        {
            var file = File.ReadAllText(@"C:\Users\CustomerSupport\Desktop\CST-117\Exercise10.txt").Split(' ');
            double count = 0;
            foreach (var value in file)
            {
                string wordstring;
                wordstring = stripPunc(value);
                if (System.Text.RegularExpressions.Regex.IsMatch(wordstring, "[t,e]$"))
                {
                    count++;
                }
            }
            Console.WriteLine(" There are" + count + " words that end in t or e\n " + " Any key to continue ");
            Console.ReadKey();
        }

        private static string stripPunc(char value)
        {
            throw new NotImplementedException();
        }
    }
    }

