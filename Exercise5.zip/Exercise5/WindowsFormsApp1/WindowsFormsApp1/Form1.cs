﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculatePIButton_Click(object sender, EventArgs e)
        {
            int numberOfTerms;
            if (int.TryParse(textBox1.Text, out numberOfTerms))
            {
                double pi = 4;
                if (numberOfTerms == 1)
                {
                    termsLabel2.Text = "Approximate Value Of PI After 1 Term: ";
                }
                else if (numberOfTerms > 1 && numberOfTerms <= int.MaxValue)
                {
                    long denominator = 3;
                    bool addSubtract = false;
                    termsLabel2.Text = " Approximate Value of PI After " + numberOfTerms.ToString() + " terms: ";
                    for (int t = 2; t <= numberOfTerms; t++)
                    {
                        switch (addSubtract)
                        {
                            case false:
                                pi = pi - ((double)4 / denominator);
                                denominator += 2;
                                addSubtract = !addSubtract;
                                break;
                            case true:
                                pi = pi + ((double)4 / denominator);
                                denominator += 2;
                                addSubtract = !addSubtract;
                                break;

                        }
                    }
                }
                approxLabel3.Text = pi.ToString();
            }
            else
            {
                MessageBox.Show(" Invalid input for Terms. Please select a number between 1 and " + int.MaxValue.ToString()); 
            }
        }
    }
}
