﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculatePIButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.termsLabel2 = new System.Windows.Forms.Label();
            this.approxLabel3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calculatePIButton
            // 
            this.calculatePIButton.Location = new System.Drawing.Point(56, 319);
            this.calculatePIButton.Name = "calculatePIButton";
            this.calculatePIButton.Size = new System.Drawing.Size(134, 57);
            this.calculatePIButton.TabIndex = 0;
            this.calculatePIButton.Text = "Calculate";
            this.calculatePIButton.UseVisualStyleBackColor = true;
            this.calculatePIButton.Click += new System.EventHandler(this.calculatePIButton_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(31, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter number of terms:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(34, 88);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 22);
            this.textBox1.TabIndex = 2;
            // 
            // termsLabel2
            // 
            this.termsLabel2.Location = new System.Drawing.Point(28, 141);
            this.termsLabel2.Name = "termsLabel2";
            this.termsLabel2.Size = new System.Drawing.Size(191, 68);
            this.termsLabel2.TabIndex = 3;
            this.termsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // approxLabel3
            // 
            this.approxLabel3.Location = new System.Drawing.Point(28, 260);
            this.approxLabel3.Name = "approxLabel3";
            this.approxLabel3.Size = new System.Drawing.Size(191, 23);
            this.approxLabel3.TabIndex = 4;
            this.approxLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 429);
            this.Controls.Add(this.approxLabel3);
            this.Controls.Add(this.termsLabel2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.calculatePIButton);
            this.Name = "Form1";
            this.Text = "Approximate PI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculatePIButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label termsLabel2;
        private System.Windows.Forms.Label approxLabel3;
    }
}

