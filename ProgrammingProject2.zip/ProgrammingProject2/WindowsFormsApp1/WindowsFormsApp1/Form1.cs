﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            breadLabel1.Text = "White";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            breadLabel1.Text = "Wheat";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            breadLabel1.Text = "9 Grain Wheat";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            breadLabel1.Text = "Italian";
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            breadLabel1.Text = "Herb / Cheese";
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            toastedLabel1.Text = "Yes";
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            toastedLabel1.Text = "No";
        }

        private void button1_Click(object sender, EventArgs e)
        {
              if(hamCheckBox1.Checked)
            {
                label4.Text += "Ham \n";
            }
              if(salamiCheckBox2.Checked)
            {
                label4.Text += "Salami \n";
            }
              if(turkeyCheckBox3.Checked)
            {
                label4.Text += "Turkey \n";
            }
              if(bolognaCheckBox4.Checked)
            {
                label4.Text += "Bologna \n";
            }
              if(lettuceCheckBox5.Checked)
            {
                label4.Text += "Lettuce \n";
            }
              if(tomatoCheckBox6.Checked)
            {
                label4.Text += "Tomato \n";
            }
              if(onionsCheckBox7.Checked)
            {
                label4.Text += "Onions \n";
            }
              if(blackOlivesCheckBox8.Checked)
            {
                label4.Text += "Black Olives \n";
            }
              if(greenPeppersCheckBox9.Checked)
            {
                label4.Text += "Green Peppers \n";
            }
              if(bananaPeppersCheckBox10.Checked)
            {
                label4.Text += "Banana Peppers \n";
            }
              if(cheeseCheckBox11.Checked)
            {
                label4.Text += "Cheese \n";
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            label4.Text = "";
            if (ListBox.SelectedIndex != -1)
            {
                Featured = ListBox.SelectedItem.ToString();
                switch (Featured)
                {
                    case "Garbage Sub":
                        label4.Text = "All Meats and Sides";
                        break;
                    case "Veggie Sub":
                        label4.Text = "All Veggies";
                        break;
                    case "All Meats Sub":
                        label4.Text = "All Meats";
                        break;
                }
            }
        }
    }
}
    

