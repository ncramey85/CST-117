﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cheeseCheckBox11 = new System.Windows.Forms.CheckBox();
            this.bananaPeppersCheckBox10 = new System.Windows.Forms.CheckBox();
            this.greenPeppersCheckBox9 = new System.Windows.Forms.CheckBox();
            this.onionsCheckBox7 = new System.Windows.Forms.CheckBox();
            this.blackOlivesCheckBox8 = new System.Windows.Forms.CheckBox();
            this.tomatoCheckBox6 = new System.Windows.Forms.CheckBox();
            this.lettuceCheckBox5 = new System.Windows.Forms.CheckBox();
            this.bolognaCheckBox4 = new System.Windows.Forms.CheckBox();
            this.turkeyCheckBox3 = new System.Windows.Forms.CheckBox();
            this.salamiCheckBox2 = new System.Windows.Forms.CheckBox();
            this.hamCheckBox1 = new System.Windows.Forms.CheckBox();
            this.Featured = new System.Windows.Forms.ListBox();
            this.breadLabel1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.toastedLabel1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(29, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(139, 170);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bread";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(7, 130);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(124, 21);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Herb / Cheese ";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(7, 103);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(66, 21);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Italian";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(6, 76);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(121, 21);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "9 Grain Wheat";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(6, 49);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(70, 21);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Wheat";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 22);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(65, 21);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "White";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton7);
            this.groupBox2.Controls.Add(this.radioButton6);
            this.groupBox2.Location = new System.Drawing.Point(29, 244);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(139, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Toasted ";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(7, 49);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(47, 21);
            this.radioButton7.TabIndex = 1;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "No";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(7, 22);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(53, 21);
            this.radioButton6.TabIndex = 0;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Yes";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cheeseCheckBox11);
            this.groupBox3.Controls.Add(this.bananaPeppersCheckBox10);
            this.groupBox3.Controls.Add(this.greenPeppersCheckBox9);
            this.groupBox3.Controls.Add(this.onionsCheckBox7);
            this.groupBox3.Controls.Add(this.blackOlivesCheckBox8);
            this.groupBox3.Controls.Add(this.tomatoCheckBox6);
            this.groupBox3.Controls.Add(this.lettuceCheckBox5);
            this.groupBox3.Controls.Add(this.bolognaCheckBox4);
            this.groupBox3.Controls.Add(this.turkeyCheckBox3);
            this.groupBox3.Controls.Add(this.salamiCheckBox2);
            this.groupBox3.Controls.Add(this.hamCheckBox1);
            this.groupBox3.Location = new System.Drawing.Point(208, 29);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 315);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Meats/Sides";
            // 
            // cheeseCheckBox11
            // 
            this.cheeseCheckBox11.AutoSize = true;
            this.cheeseCheckBox11.Location = new System.Drawing.Point(6, 288);
            this.cheeseCheckBox11.Name = "cheeseCheckBox11";
            this.cheeseCheckBox11.Size = new System.Drawing.Size(78, 21);
            this.cheeseCheckBox11.TabIndex = 10;
            this.cheeseCheckBox11.Text = "Cheese";
            this.cheeseCheckBox11.UseVisualStyleBackColor = true;
            // 
            // bananaPeppersCheckBox10
            // 
            this.bananaPeppersCheckBox10.AutoSize = true;
            this.bananaPeppersCheckBox10.Location = new System.Drawing.Point(6, 261);
            this.bananaPeppersCheckBox10.Name = "bananaPeppersCheckBox10";
            this.bananaPeppersCheckBox10.Size = new System.Drawing.Size(140, 21);
            this.bananaPeppersCheckBox10.TabIndex = 9;
            this.bananaPeppersCheckBox10.Text = "Banana Peppers ";
            this.bananaPeppersCheckBox10.UseVisualStyleBackColor = true;
            // 
            // greenPeppersCheckBox9
            // 
            this.greenPeppersCheckBox9.AutoSize = true;
            this.greenPeppersCheckBox9.Location = new System.Drawing.Point(6, 238);
            this.greenPeppersCheckBox9.Name = "greenPeppersCheckBox9";
            this.greenPeppersCheckBox9.Size = new System.Drawing.Size(127, 21);
            this.greenPeppersCheckBox9.TabIndex = 8;
            this.greenPeppersCheckBox9.Text = "Green Peppers";
            this.greenPeppersCheckBox9.UseVisualStyleBackColor = true;
            // 
            // onionsCheckBox7
            // 
            this.onionsCheckBox7.AutoSize = true;
            this.onionsCheckBox7.Location = new System.Drawing.Point(6, 184);
            this.onionsCheckBox7.Name = "onionsCheckBox7";
            this.onionsCheckBox7.Size = new System.Drawing.Size(75, 21);
            this.onionsCheckBox7.TabIndex = 6;
            this.onionsCheckBox7.Text = "Onions";
            this.onionsCheckBox7.UseVisualStyleBackColor = true;
            // 
            // blackOlivesCheckBox8
            // 
            this.blackOlivesCheckBox8.AutoSize = true;
            this.blackOlivesCheckBox8.Location = new System.Drawing.Point(6, 211);
            this.blackOlivesCheckBox8.Name = "blackOlivesCheckBox8";
            this.blackOlivesCheckBox8.Size = new System.Drawing.Size(107, 21);
            this.blackOlivesCheckBox8.TabIndex = 7;
            this.blackOlivesCheckBox8.Text = "Black Olives";
            this.blackOlivesCheckBox8.UseVisualStyleBackColor = true;
            // 
            // tomatoCheckBox6
            // 
            this.tomatoCheckBox6.AutoSize = true;
            this.tomatoCheckBox6.Location = new System.Drawing.Point(6, 157);
            this.tomatoCheckBox6.Name = "tomatoCheckBox6";
            this.tomatoCheckBox6.Size = new System.Drawing.Size(78, 21);
            this.tomatoCheckBox6.TabIndex = 5;
            this.tomatoCheckBox6.Text = "Tomato";
            this.tomatoCheckBox6.UseVisualStyleBackColor = true;
            // 
            // lettuceCheckBox5
            // 
            this.lettuceCheckBox5.AutoSize = true;
            this.lettuceCheckBox5.Location = new System.Drawing.Point(6, 130);
            this.lettuceCheckBox5.Name = "lettuceCheckBox5";
            this.lettuceCheckBox5.Size = new System.Drawing.Size(77, 21);
            this.lettuceCheckBox5.TabIndex = 4;
            this.lettuceCheckBox5.Text = "Lettuce";
            this.lettuceCheckBox5.UseVisualStyleBackColor = true;
            // 
            // bolognaCheckBox4
            // 
            this.bolognaCheckBox4.AutoSize = true;
            this.bolognaCheckBox4.Location = new System.Drawing.Point(6, 103);
            this.bolognaCheckBox4.Name = "bolognaCheckBox4";
            this.bolognaCheckBox4.Size = new System.Drawing.Size(82, 21);
            this.bolognaCheckBox4.TabIndex = 3;
            this.bolognaCheckBox4.Text = "Bologna";
            this.bolognaCheckBox4.UseVisualStyleBackColor = true;
            // 
            // turkeyCheckBox3
            // 
            this.turkeyCheckBox3.AutoSize = true;
            this.turkeyCheckBox3.Location = new System.Drawing.Point(6, 76);
            this.turkeyCheckBox3.Name = "turkeyCheckBox3";
            this.turkeyCheckBox3.Size = new System.Drawing.Size(74, 21);
            this.turkeyCheckBox3.TabIndex = 2;
            this.turkeyCheckBox3.Text = "Turkey";
            this.turkeyCheckBox3.UseVisualStyleBackColor = true;
            // 
            // salamiCheckBox2
            // 
            this.salamiCheckBox2.AutoSize = true;
            this.salamiCheckBox2.Location = new System.Drawing.Point(6, 49);
            this.salamiCheckBox2.Name = "salamiCheckBox2";
            this.salamiCheckBox2.Size = new System.Drawing.Size(72, 21);
            this.salamiCheckBox2.TabIndex = 1;
            this.salamiCheckBox2.Text = "Salami";
            this.salamiCheckBox2.UseVisualStyleBackColor = true;
            this.salamiCheckBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // hamCheckBox1
            // 
            this.hamCheckBox1.AutoSize = true;
            this.hamCheckBox1.Location = new System.Drawing.Point(6, 21);
            this.hamCheckBox1.Name = "hamCheckBox1";
            this.hamCheckBox1.Size = new System.Drawing.Size(59, 21);
            this.hamCheckBox1.TabIndex = 0;
            this.hamCheckBox1.Text = "Ham";
            this.hamCheckBox1.UseVisualStyleBackColor = true;
            this.hamCheckBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Featured
            // 
            this.Featured.FormattingEnabled = true;
            this.Featured.ItemHeight = 16;
            this.Featured.Items.AddRange(new object[] {
            "Garbage Sub",
            "Veggie Sub",
            "All Meat Sub"});
            this.Featured.Location = new System.Drawing.Point(414, 37);
            this.Featured.Name = "Featured";
            this.Featured.Size = new System.Drawing.Size(96, 52);
            this.Featured.TabIndex = 3;
            // 
            // breadLabel1
            // 
            this.breadLabel1.Location = new System.Drawing.Point(516, 37);
            this.breadLabel1.Name = "breadLabel1";
            this.breadLabel1.Size = new System.Drawing.Size(100, 23);
            this.breadLabel1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(208, 375);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Meat/Sides";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // toastedLabel1
            // 
            this.toastedLabel1.Location = new System.Drawing.Point(516, 76);
            this.toastedLabel1.Name = "toastedLabel1";
            this.toastedLabel1.Size = new System.Drawing.Size(88, 23);
            this.toastedLabel1.TabIndex = 10;
            this.toastedLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(415, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 252);
            this.label4.TabIndex = 11;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(418, 374);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Feature Subs";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 471);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.toastedLabel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.breadLabel1);
            this.Controls.Add(this.Featured);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Sub Shop ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cheeseCheckBox11;
        private System.Windows.Forms.CheckBox bananaPeppersCheckBox10;
        private System.Windows.Forms.CheckBox greenPeppersCheckBox9;
        private System.Windows.Forms.CheckBox blackOlivesCheckBox8;
        private System.Windows.Forms.CheckBox salamiCheckBox2;
        private System.Windows.Forms.CheckBox hamCheckBox1;
        private System.Windows.Forms.CheckBox turkeyCheckBox3;
        private System.Windows.Forms.CheckBox bolognaCheckBox4;
        private System.Windows.Forms.CheckBox lettuceCheckBox5;
        private System.Windows.Forms.CheckBox tomatoCheckBox6;
        private System.Windows.Forms.CheckBox onionsCheckBox7;
        private System.Windows.Forms.ListBox Featured;
        private System.Windows.Forms.Label breadLabel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label toastedLabel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
    }
}

