﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double run1;
                double run2;
                double run3;
                double run4;
                double run5;
                double run6;
                double run7;
                double average;

                // Gets the run times.
                run1 = double.Parse(textBox1.Text);
                run2 = double.Parse(textBox2.Text);
                run3 = double.Parse(textBox3.Text);
                run4 = double.Parse(textBox4.Text);
                run5 = double.Parse(textBox5.Text);
                run6 = double.Parse(textBox6.Text);
                run7 = double.Parse(textBox7.Text);

                //Calculates the average between the 7 run times. 
                average = (run1 + run2 + run3 + run4 + run5 + run6 + run7) / 7.0;

                label8.Text = average.ToString("n1");


            }
            catch (Exception)
            {
                // Displayed when anything other than a number is inputted into program.
                MessageBox.Show("Please use input correct run time");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Clears all textboxes and outputs after average is calculated. 
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            label8.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Lets user close out of program.
            this.Close();
        }
    }
}
