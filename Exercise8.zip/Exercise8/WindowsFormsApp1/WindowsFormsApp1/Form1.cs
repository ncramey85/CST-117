﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    public double fatCalories(string a)
        {
            double r = Convert.ToDouble(a);
            r = r * 9;
            return r;
        }
    public double carbCalories(string b)
        {
            double r = Convert.ToDouble(b);
            r = r * 4;
            return r;
        }

        private void calculateButton1_Click(object sender, EventArgs e)
        {
            string results = Convert.ToString(fatCalories(textBox1.Text));
            fatResultLabel5.Text = results;
            results = Convert.ToString(carbCalories(textBox2.Text));
            carbResultsLabel6.Text = results;
        }

        private void clearButton2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            fatResultLabel5.Text = "";
            carbResultsLabel6.Text = "";
        }

        private void exitButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
