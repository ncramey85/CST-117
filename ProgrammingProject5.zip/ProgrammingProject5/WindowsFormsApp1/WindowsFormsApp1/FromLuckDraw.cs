﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FromLuckDraw : Form
    {
        public FromLuckDraw()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int luckyNumber;
            if (int.TryParse(textBox1.Text, out luckyNumber) && (luckyNumber <= 50))
            {
                FormLuckNumber luckForm = new FormLuckNumber();
                Point pointArea = new Point(10, 10);
                Random rand = new Random();
                for (int a = 0; a < luckyNumber; ++a)
                {
                    Button garbage = new Button();
                    garbage.Text = Convert.ToString(rand.Next(0, luckyNumber));
                    garbage.Location = pointArea;
                    garbage.Size = new Size(250, 50);
                    pointArea.Offset(0, garbage.Height + 5);
                    luckForm.Controls.Add(garbage);
                }
                luckForm.ShowDialog();
            }
            else
            {
                textBox1.Text = "";
                this.ActiveControl = textBox1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
