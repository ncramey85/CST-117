﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int seconds;
            if (int.TryParse(textBox1.Text, out seconds))
            {
                if (seconds >= 60 && seconds < 3600)
                {
                    int minutes = seconds / 60;
                    if (minutes == 1)
                    {
                        label3.Text = seconds.ToString() + " total seconds " + minutes.ToString() + " minute. ";
                    }
                    else
                    {
                        label3.Text = seconds.ToString() + " total seconds " + minutes.ToString() + " minutes. ";
                    }

                }
                else if (seconds >= 3600 && seconds < 86400)
                {
                    int hours = seconds / 3600;
                    if (hours == 1)
                    {
                        label3.Text = seconds.ToString() + " total seconds " + hours.ToString() + " hour. ";
                    }
                    else
                    {
                        label3.Text = seconds.ToString() + " total seconds " + hours.ToString() + " hours. ";
                    }

                }
                else if (seconds >= 86400)
                {
                    int days = seconds / 86400;
                    if(days ==1)
                    {
                        label3.Text = seconds.ToString() + " total seconds " + days.ToString() + " day. ";
                    }
                    else
                    {
                        label3.Text = seconds.ToString() + " total seconds " + days.ToString() + " days. ";
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a number equal to or greater than 60");
                }
            }
          else
            {
                MessageBox.Show("Please enter a number.");
            }         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            label3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
