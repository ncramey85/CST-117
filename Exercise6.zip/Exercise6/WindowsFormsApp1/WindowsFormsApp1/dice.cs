﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class dice
    {
        private int numberOfRolls;
        private int numberOfSides;
        Random rand = new Random();
        public int NumberOfSides
        {
            get
            {
                return numberOfSides;
            }
            set
            {
                numberOfSides = value;
            }
        }
        public int NumberOfRolls
        {
            get
            {
                return numberOfRolls;
            }

        }
        public int RollDie()
        {
            numberOfRolls++;
            return this.rand.Next(1, this.numberOfSides + 1);
        }
        public dice(int numberOfSides)
        {
            if (numberOfSides > 20)
            {
                this.numberOfSides = 20;
            }
            else if (numberOfSides < 4)
            {
                this.numberOfSides = 4;
            }
            else
            {
                this.numberOfSides = numberOfSides;
            }
        }
        public dice()
        {
            this.numberOfSides = 6;
        }
    }
}

