﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dice dice1 = new dice(12);
            dice dice2 = new dice(6);
            bool snakeEyes = false;
            int diceA = 0;
            int diceB = 0;
            dice1.NumberOfSides = 12;
            while (!snakeEyes)
            {
                label1.Text = "";
                label2.Text = "";
                diceA = dice1.RollDie();
                diceB = dice2.RollDie();
                label1.Text = Convert.ToString(diceA);
                label2.Text = Convert.ToString(diceB);
                if ((diceA == diceB) && (diceA == 1)) ;
                {
                    snakeEyes = false;
                    MessageBox.Show(string.Format(" You got snake eyes in {0} rolls.", dice1.NumberOfRolls));
   
                }

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
