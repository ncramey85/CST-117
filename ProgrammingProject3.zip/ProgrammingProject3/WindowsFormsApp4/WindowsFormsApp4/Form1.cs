﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        private String[] words;
        public TextFileProcessor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text | *.txt | Word | *.doc";
            saveFileDialog.FileName = "Converted Text File";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName);
                streamWriter.Write("Original Text /r/n");
                foreach (string word in words)
                {
                    streamWriter.Write(word + " ");
                }
                streamWriter.Write("\r\n\r\n" + textBox3.Text + "\r\n\r\n" + textBox2.Text + "\r\n\r\n" + textBox1.Text +
                    "\r\n\r\n" + textBox4.Text);
                streamWriter.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Open File Text";
            openFileDialog.Filter = "Text | *.txt";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamReader streamReader = new StreamReader(File.OpenRead(openFileDialog.FileName));
                words = streamReader.ReadToEnd().Split(' ');
                textBox3.Text = " All Lower caser are: \r\n\r\n";
                char[] vowels = new char[] { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
                String longestWord = "";
                String mostVowels = "";
                int mostVowelsInt = 0;
                int a = 0;
                foreach (String word in words)
                {
                    // Sets text file to all lowercase.
                    textBox3.Text = textBox3.Text + words[a].ToLower + " ";
                    if (word.Contains('.') | word.Contains(',') | word.Contains('!') | word.Contains('?'))
                    {
                        words[a] = words[a].Remove(words[a].Length - 1);
                    }
                    if (words[a].Length > longestWord.Length)
                    {
                        longestWord = word[a];
                    }
                    // Finds all the vowels in doc. 
                    int numberofVowels = 0;
                    char[] eachWordAsChars = word.ToCharArray();
                    foreach (char character in eachWordAsChars)
                    {
                        if (vowels.Contains(character))
                        {
                            numberofVowels++;
                        }
                    }
                    if (numberofVowels > mostVowelsInt)
                    {
                        mostVowels = words[a];
                        mostVowelsInt = numberofVowels;
                    }
                    a++;
                }
                // Gets all the data together
                String[] sortedStrings = new string[words.Length];
                int b = 0;
                foreach (string tempWord in words)
                {
                    sortedStrings[b] = tempWord;
                    b++;
                }
                //Populates the textboxes with appropiate info.
                Array.Sort(sortedStrings);
                textBox2.Text = " Alphabetically First Word: " + sortedStrings.First() + "\r\nAlphabetically Last Word: " + sortedStrings.Last();
                textBox1.Text = " Longest Word is: " + longestWord;
                textBox4.Text = " Word with the most vowels is: " + mostVowels;
                // Closes the stream.
                streamReader.Dispose();
               
            }
        }
    }
}
